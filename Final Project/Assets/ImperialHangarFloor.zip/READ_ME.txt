Hello and thank you for downloading my Imperial Hangar Floor Substance Material. If you plan to utilize my sbs file, then you will need to follow these steps for one of the nodes I used.
This node was not of my creation and don't take credit for creating it myself at all. This is a custom node created and share to the Substance community to utilize for better Curvature/Cavity map creation.

I've added the RO_Cavity_better sbs file into the zip folder as this was a custom node I utilized within my sbs file. You must add this into your Substance Designer packages for this dependency to reference correctly.

These are the steps you must take to get this done:

1. Copy the RO_Cavity_better sbs file
2. Navigate to your Substance Designer folders.
3. Specifically the folder location should look like this: (Where you installed your Substance Folder location) > 5 > resources > packages.
4. Paste the RO_Cavity_better sbs file into the packages folder. 

Once you have done this, the sbs file will correctly reference the dependency for the RO_Cavity_better.

-Ryan Staniszewski